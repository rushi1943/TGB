jQuery( function ( $ ) {
	// Add class for seamless meta boxes.
	$( '.rwmb-meta-box--seamless' ).closest( '.postbox' ).addClass( 'rwmb-seamless' );
} );
