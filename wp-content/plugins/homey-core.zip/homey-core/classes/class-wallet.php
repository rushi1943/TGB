<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Homey_Wallet {
    
    /**
     * Initialize custom post type
     *
     * @access public
     * @return void
     */
    public static function init() {
        
    }


    /**
     * Render Wallet
     * @return void
     */
    public static function render()
    {
        /*$template = apply_filters( 'homey_dashboard_template_path', HOMEY_TEMPLATES . '/dashboard.php' );

        if ( file_exists( $template ) ) {
            include_once( $template );
        }*/
    }

        
}
?>