<?php
$top_bar_slogan = homey_option('top_bar_slogan');
?>
<ul class="top-slogan list-unstyled">
	<li><?php echo esc_attr($top_bar_slogan); ?></li>
</ul>
